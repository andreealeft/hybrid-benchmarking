"""Reading the files people actually have.

The library asks for condition numbers, layer sizes and improving-column counts.
Nobody has those.  What they have is a file: a DIMACS network, a knapsack
instance from Pisinger's generator, a matrix from Matrix Market, a model in MPS.
This package turns such a file into a plain description of the instance, and
:mod:`..classical` runs the classical algorithm on it to produce the log.

The readers hold no cost logic and import nothing from the rest of the library,
so a wrong count here cannot become a plausible gate count elsewhere -- it
becomes a graph with the wrong number of edges, which the tests catch.  They are
standard-library only: numpy enters one step later, with the solvers.

Every reader offers ``parse(text, name, source)`` and ``read(path)``, except
:mod:`.dimacs`, which reads two unrelated formats and so names them:
``parse_max_flow`` / ``read_max_flow`` and ``parse_graph`` / ``read_graph``.  All
of them raise :class:`InstanceError` on anything they cannot read rather than
guessing.  Guessing is the failure mode that matters here: a
knapsack layout misread by one column still produces numbers.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Tuple, Union

__all__ = [
    "Graph",
    "Instance",
    "InstanceError",
    "Knapsack",
    "LinearProgram",
    "Matrix",
    "MultidimensionalKnapsack",
    "Network",
    "QuadraticKnapsack",
    "detect",
    "read",
]


class InstanceError(ValueError):
    """The file is not what it claims to be, or not something we can read."""


# ---------------------------------------------------------------------------
# what a file can turn out to hold
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Instance:
    """Common to everything read from disk."""

    #: Usually the file stem, or the name the format states internally.
    name: str
    #: Where it was read from, for the log to cite.
    source: str
    #: Which reader produced it, and in which of its layouts: ``dimacs-max``,
    #: ``dimacs-edge``, ``pisinger``, ``martello-toth``, ``matrix-market``,
    #: ``mps``.
    layout: str

    def describe(self) -> str:
        return "{} ({})".format(self.name, self.layout)


@dataclass(frozen=True)
class Network(Instance):
    """A directed graph with arc capacities, a source and a sink.

    Vertices are numbered from zero, whatever the file did.  Parallel arcs are
    kept as they are written: a maximum-flow solver is entitled to see them.
    """

    vertices: int
    #: ``(tail, head, capacity)``, vertices zero-based.
    arcs: Tuple[Tuple[int, int, float], ...]
    #: Where the flow starts and ends, zero-based.  Named at length because
    #: :attr:`Instance.source` is the file this came from, and a dataclass field
    #: called ``source`` on both would silently be one field.
    source_vertex: int = 0
    sink_vertex: int = 0

    def describe(self) -> str:
        return "{}: {} vertices, {} arcs, {} to {}".format(
            self.name, self.vertices, len(self.arcs),
            self.source_vertex, self.sink_vertex,
        )


@dataclass(frozen=True)
class Graph(Instance):
    """An undirected graph, without weights.

    Edges are normalised -- ``u < v``, no self-loops, no duplicates -- because
    the linear programs built from them have one constraint per edge, and a
    duplicate edge would silently add a redundant row.
    """

    vertices: int
    #: ``(u, v)`` with ``u < v``, vertices zero-based, sorted.
    edges: Tuple[Tuple[int, int], ...]

    def describe(self) -> str:
        return "{}: {} vertices, {} edges".format(
            self.name, self.vertices, len(self.edges)
        )


@dataclass(frozen=True)
class Knapsack(Instance):
    """Items with a value and a cost, and a budget.

    Profits and weights are integers because the circuits that cost this
    problem read their binary representations: where the ones sit in each value
    changes the gate count, so a float here would not merely be imprecise, it
    would be meaningless.
    """

    profits: Tuple[int, ...]
    weights: Tuple[int, ...]
    capacity: int
    #: The optimal value, where the file states one.  Some generators record it.
    optimum: Optional[int] = None

    def describe(self) -> str:
        return "{}: {} items, capacity {}".format(
            self.name, len(self.profits), self.capacity
        )


@dataclass(frozen=True)
class QuadraticKnapsack(Instance):
    """Items with their own value, and a bonus for each pair taken together.

    :attr:`pairs` maps an unordered pair to what it earns **in addition** when
    both items are chosen, keyed ``(higher, lower)`` and holding the total for
    that pair -- the circuit performs one addition per unordered pair, so a
    symmetric matrix's two entries belong together here as one number.

    Bonuses only.  A pair worth less than nothing has no gate in the circuit
    that costs this, so a negative entry is refused rather than carried.
    """

    profits: Tuple[int, ...]
    weights: Tuple[int, ...]
    capacity: int
    #: ``{(m, m'): value}`` with ``m > m'``; absent pairs earn nothing.
    pairs: Dict[Tuple[int, int], int] = field(default_factory=dict)
    optimum: Optional[int] = None

    def describe(self) -> str:
        return "{}: {} items, {} paired, capacity {}".format(
            self.name, len(self.profits), len(self.pairs), self.capacity
        )


@dataclass(frozen=True)
class MultidimensionalKnapsack(Instance):
    """Items with one value and several costs, under one budget per dimension.

    :attr:`weights` is one row per dimension, each of length ``len(profits)``;
    :attr:`capacities` holds one budget per dimension, in the same order.
    """

    profits: Tuple[int, ...]
    #: ``weights[i][m]`` -- what item ``m`` costs in dimension ``i``.
    weights: Tuple[Tuple[int, ...], ...]
    capacities: Tuple[int, ...]
    optimum: Optional[int] = None

    def describe(self) -> str:
        return "{}: {} items, {} dimensions".format(
            self.name, len(self.profits), len(self.weights)
        )


@dataclass(frozen=True)
class Matrix(Instance):
    """A sparse matrix, as Matrix Market states it.

    Symmetric files store one triangle; :attr:`entries` holds both, so that
    anything counting non-zeros per row gets the right answer without having to
    remember what the header said.
    """

    rows: int
    columns: int
    #: ``(row, column, value)``, zero-based, both triangles present.
    entries: Tuple[Tuple[int, int, float], ...]
    symmetric: bool = False

    def describe(self) -> str:
        return "{}: {} by {}, {} non-zeros{}".format(
            self.name, self.rows, self.columns, len(self.entries),
            ", symmetric" if self.symmetric else "",
        )


@dataclass(frozen=True)
class LinearProgram(Instance):
    """A linear program in the shape an MPS file states it.

    Deliberately not the standard form: the translation to ``Ax = b, x >= 0``
    adds columns, and doing it here would lose the distinction between a bound
    the file stated and a slack the translation invented.  :mod:`..classical.lp`
    does that step, and is tested against the shapes :mod:`..problems` predicts.
    """

    #: Column names, in file order.
    columns: Tuple[str, ...]
    #: Constraint row names, objective excluded, in file order.
    rows: Tuple[str, ...]
    #: ``'L'``, ``'G'`` or ``'E'`` per row.
    senses: Tuple[str, ...]
    #: Objective coefficients, per column.
    objective: Tuple[float, ...]
    #: ``(row index, column index, value)``, zero-based on :attr:`rows` and
    #: :attr:`columns`.
    matrix: Tuple[Tuple[int, int, float], ...]
    #: Right-hand side, per row; zero where the file gives none.
    rhs: Tuple[float, ...]
    #: Per row: the RANGES entry, or ``None``.  A range turns one row into two
    #: bounds on the same expression.
    ranges: Tuple[Optional[float], ...] = ()
    #: Lower bound per column, zero by default.
    lower: Tuple[float, ...] = ()
    #: Upper bound per column, ``None`` for infinite.
    upper: Tuple[Optional[float], ...] = ()
    #: True where the file declared the column integer -- by an INTORG/INTEND
    #: marker, or by a ``BV``, ``LI`` or ``UI`` bound, which imply it.  The
    #: relaxation is what gets solved; the flag is kept so the log can say so.
    integer: Tuple[bool, ...] = ()
    maximise: bool = False
    objective_name: str = ""
    objective_constant: float = 0.0

    def describe(self) -> str:
        return "{}: {} columns, {} rows{}".format(
            self.name, len(self.columns), len(self.rows),
            ", relaxed from an integer program" if any(self.integer) else "",
        )


# ---------------------------------------------------------------------------
# working out what a file is
# ---------------------------------------------------------------------------

#: Extension to layout, where the extension is decisive.
_BY_SUFFIX = {
    ".max": "dimacs-max",
    ".clq": "dimacs-edge",
    ".col": "dimacs-edge",
    ".edges": "dimacs-edge",
    ".mtx": "matrix-market",
    ".mps": "mps",
    ".kp": "pisinger",
    ".qkp": "quadratic-knapsack",
    ".mdkp": "multidimensional-knapsack",
}


def detect(path: Union[str, Path]) -> str:
    """Which reader this file wants, from its name and its first few lines.

    The extension decides where it can; otherwise the header does.  Where
    neither does, this raises rather than picking the most likely one -- a
    knapsack file read as an edge list produces a graph, not an error.
    """
    location = Path(path).expanduser()
    suffix = location.suffix.lower()
    if suffix in _BY_SUFFIX:
        return _BY_SUFFIX[suffix]

    try:
        head = location.open("r", errors="replace").read(4096)
    except OSError as error:
        raise InstanceError("cannot read {}: {}".format(location, error))

    lowered = head.lstrip().lower()
    if lowered.startswith("%%matrixmarket"):
        return "matrix-market"

    numeric = _numeric_family(head)
    if numeric:
        return numeric

    for line in head.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        words = stripped.split()
        head_word = words[0].upper()
        if head_word in ("NAME", "OBJSENSE", "ROWS") and len(words) <= 3:
            return "mps"
        if head_word == "P" and len(words) >= 2:
            what = words[1].lower()
            if what in ("max", "flow"):
                return "dimacs-max"
            if what in ("edge", "edges", "col", "clique"):
                return "dimacs-edge"
        if head_word == "N" and len(words) == 2:
            return "pisinger"
        if stripped.startswith("c ") or stripped.startswith("*"):
            continue  # a comment in several of these formats; keep looking

    raise InstanceError(
        "cannot tell what {} is; name it .max, .clq, .mtx, .mps, .kp, .qkp or "
        ".mdkp, or say which format it is outright".format(location.name)
    )


def _numeric_family(head: str) -> str:
    """Tell the three all-but-numeric knapsack layouts apart, or say nothing.

    The benchmark sets for these ship as ``.txt``, which is no help at all, so
    the extension cannot decide and the shape of the opening has to.  Each of
    the three opens differently enough to be recognised without reading further:

    * a ``problem NAME`` marker anywhere near the top belongs to the
      multidimensional set's second layout, which is the only one that names its
      instances;
    * an opening line of nothing but numbers is the multidimensional set's
      counted layout -- one number is a problem count, two are a dimension and
      an item count;
    * an opening line that is a name, followed by a line holding one number, is
      a quadratic knapsack: the name, then the item count;
    * a name followed by ``n <count>`` is Pisinger's 0-1 layout.

    Anything else returns the empty string and lets :func:`detect` refuse, which
    is the point.  A knapsack read as the wrong knapsack does not fail -- it
    produces an instance of the wrong size and a gate count to match.
    """
    lines = [line.strip() for line in head.splitlines()]
    meaningful = [line for line in lines
                  if line and not line.startswith(("*", "%", "#"))]
    if not meaningful:
        return ""

    for line in lines[:60]:
        words = line.split()
        if len(words) >= 2 and words[0].lower() == "problem":
            return "multidimensional-knapsack"

    first = meaningful[0].split()
    if all(_is_number(word) for word in first):
        return "multidimensional-knapsack" if len(first) in (1, 2) else ""

    if len(meaningful) < 2:
        return ""
    second = meaningful[1].split()
    if len(second) == 1 and _is_number(second[0]):
        return "quadratic-knapsack"
    if len(second) == 2 and second[0].lower() == "n" and _is_number(second[1]):
        return "pisinger"
    return ""


def _is_number(word: str) -> bool:
    try:
        float(word)
    except ValueError:
        return False
    return True


def read(path: Union[str, Path], layout: str = "") -> Instance:
    """Read an instance file, choosing the reader by :func:`detect`."""
    location = Path(path).expanduser()
    if not location.exists():
        raise InstanceError("no such file: {}".format(location))
    chosen = layout or detect(location)

    if chosen == "dimacs-max":
        from .dimacs import read_max_flow

        return read_max_flow(location)
    if chosen == "dimacs-edge":
        from .dimacs import read_graph

        return read_graph(location)
    if chosen == "pisinger":
        from .knapsack import read as read_knapsack

        return read_knapsack(location)
    if chosen == "quadratic-knapsack":
        from .qkp import read as read_quadratic

        return read_quadratic(location)
    if chosen == "multidimensional-knapsack":
        from .mdkp import read as read_multidimensional

        return read_multidimensional(location)
    if chosen == "matrix-market":
        from .matrixmarket import read as read_matrix

        return read_matrix(location)
    if chosen == "mps":
        from .mps import read as read_mps

        return read_mps(location)
    raise InstanceError("no reader for {!r}".format(chosen))
